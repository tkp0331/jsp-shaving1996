__version__ = '0.1.0'
from .main import adjust_heads, adjust_tails, iterated_shaving, iterated_full_shaving
